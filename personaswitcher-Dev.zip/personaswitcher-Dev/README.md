[Persona Switcher](https://addons.mozilla.org/en-US/firefox/addon/personaswitcher/)
===================================================================================

Easily switch between personas in Mozilla Firefox, Thunderbird, and
SeaMonkey. This extension allows one to switch between personas via
keyboard combinations, or every N minutes; it also allows one to specify
switching to a random persona, all can be set via perferences.
